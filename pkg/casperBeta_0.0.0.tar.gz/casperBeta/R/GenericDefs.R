setGeneric("genePlot", function(gene, genome, refflat, names.arg, xlab='', ylab='', xlim, cex=1, ...) standardGeneric("genePlot"))
setGeneric("rangesPlot",function(x, gene, genome, refflat, exonProfile=TRUE, maxFragLength=300, xlab='', ylab='', xlim, ...) standardGeneric("rangesPlot"))
