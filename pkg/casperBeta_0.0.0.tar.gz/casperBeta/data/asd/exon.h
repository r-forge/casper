class Exon
{
public:
	int id;
	int start;
	int end;
	int length;

	Exon(int id, int start, int end);
};
