#include "stdafx.h"
#include "exon.h"

Exon::Exon(int id, int length)
{
	this->id = id;
	this->length = length;
}
