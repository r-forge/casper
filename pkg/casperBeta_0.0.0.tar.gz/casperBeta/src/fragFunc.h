int buildFrags(hash_t *fragsHashPtr, SEXP reid, int *rid, int *start, int *exon, int nreads, path_t *frags);
void addExon2Frag(int exon, int start, int pos, path_t *frags, int first);


