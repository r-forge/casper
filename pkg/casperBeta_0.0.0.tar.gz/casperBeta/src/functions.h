void addRead2Frag(char *holder, int totF, read_t *frags, int read);
int *procCigar(char *cigar);
