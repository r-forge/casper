class Exon
{
public:
	int id;
	int length;

	Exon(int id, int length);
};
