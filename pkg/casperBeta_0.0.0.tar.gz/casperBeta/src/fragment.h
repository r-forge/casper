
class Fragment
{
public:
	int* left;
	int* right;
	int leftc;
	int rightc;
	int count;

	Fragment(int leftc, int rightc, int count);
};
